package Java8Examples;
@FunctionalInterface
interface InterfaceEx4
{
	void Method1();
}
//@FunctionalInterface
interface InterfaceEx5 extends InterfaceEx4
{
	void Method2();
}

public class Example4 {
public static void main(String[] args) {
	
}
}
